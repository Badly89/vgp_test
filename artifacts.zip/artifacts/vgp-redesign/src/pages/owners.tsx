import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Search, Users, Mail, Phone, X, FileText, ShieldCheck, Home, User, Calendar, Link2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { mockData, getBuildingById, getResidentByOwnerId, type Owner } from "@/lib/mockData";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

export default function Owners() {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Owner | null>(null);

  const grouped = useMemo(() => {
    const filtered = mockData.owners.filter((o) =>
      o.fullName.toLowerCase().includes(search.toLowerCase())
    );
    const groups = new Map<string, typeof mockData.owners>();
    for (const o of filtered) {
      const b = getBuildingById(o.buildingId);
      const key = b ? `${b.street} ${b.house}` : "Без адреса";
      const arr = groups.get(key) ?? [];
      arr.push(o);
      groups.set(key, arr);
    }
    return Array.from(groups.entries()).sort((a, b) => a[0].localeCompare(b[0], "ru"));
  }, [search]);

  const selectedBuilding = selected ? getBuildingById(selected.buildingId) : null;
  const linkedResident = selected ? getResidentByOwnerId(selected.id) : undefined;

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 max-w-7xl mx-auto">
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground font-mono mb-2">Раздел / Реестр</p>
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Собственники жилья</h1>
        <p className="text-muted-foreground mt-1">{mockData.owners.length} записей, сгруппировано по адресам</p>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Поиск по ФИО..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {grouped.map(([address, owners], i) => (
          <motion.div key={address} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}>
            <Card>
              <CardContent className="p-0">
                <div className="px-5 py-3 border-b border-border bg-muted/30 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-1.5 rounded bg-primary/10 text-primary">
                      <Users className="w-3.5 h-3.5" />
                    </div>
                    <h3 className="font-semibold">{address}</h3>
                  </div>
                  <Badge variant="secondary" className="font-mono">{owners.length} {owners.length === 1 ? "собственник" : "собственников"}</Badge>
                </div>
                <div className="divide-y divide-border">
                  {owners.map((o) => (
                    <div
                      key={o.id}
                      onClick={() => setSelected(o)}
                      className="px-5 py-3 flex items-center justify-between hover:bg-muted/30 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-4 min-w-0">
                        <div className="font-mono text-xs text-muted-foreground w-16 shrink-0">{o.id}</div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-medium truncate">{o.fullName}</p>
                            {o.residentId && (
                              <Badge variant="outline" className="text-[10px] font-normal gap-1 px-1.5 py-0 h-4">
                                <Link2 className="w-2.5 h-2.5" /> житель
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-3 mt-0.5 text-xs text-muted-foreground">
                            <span>{o.ownershipBasis}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <div className="text-right hidden md:block">
                          <p className="text-xs text-muted-foreground">кв. {o.apartment}</p>
                        </div>
                        <Badge
                          variant={o.ownershipType === "Частная" ? "default" : "secondary"}
                          className="font-normal text-xs"
                        >
                          {o.ownershipType}
                        </Badge>
                        <Badge variant="outline" className="font-mono text-xs">{o.share}%</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          {selected && (
            <>
              <SheetHeader className="text-left">
                <p className="font-mono text-xs text-muted-foreground">{selected.id}</p>
                <SheetTitle className="text-2xl">{selected.fullName}</SheetTitle>
                <div className="flex items-center gap-2 mt-2 flex-wrap">
                  <Badge variant={selected.ownershipType === "Частная" ? "default" : "secondary"}>
                    {selected.ownershipType} собственность
                  </Badge>
                  <Badge variant="outline" className="font-mono">Доля {selected.share}%</Badge>
                  {linkedResident && (
                    <Badge className="bg-[hsl(160,40%,35%)]/10 text-[hsl(160,45%,25%)] gap-1">
                      <Link2 className="w-3 h-3" /> числится в реестре жителей
                    </Badge>
                  )}
                </div>
              </SheetHeader>

              <div className="mt-6 space-y-6">
                <section>
                  <h3 className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5" /> Право собственности
                  </h3>
                  <div className="rounded-lg border border-border bg-muted/20 p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Основание</span>
                      <span className="font-medium text-sm text-right">{selected.ownershipBasis}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Тип собственности</span>
                      <Badge variant={selected.ownershipType === "Частная" ? "default" : "secondary"} className="font-normal">
                        {selected.ownershipType}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Доля в праве</span>
                      <span className="font-mono font-semibold">{selected.share}%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5" /> Дата регистрации
                      </span>
                      <span className="font-mono text-sm">{format(new Date(selected.ownershipDate), "d MMM yyyy", { locale: ru })}</span>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-border/40">
                      <span className="text-sm text-muted-foreground flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5" /> Документ
                      </span>
                      <span className="font-mono text-xs">{selected.documentNumber}</span>
                    </div>
                  </div>
                </section>

                <section>
                  <h3 className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                    <Home className="w-3.5 h-3.5" /> Объект собственности
                  </h3>
                  <div className="rounded-lg border border-border bg-muted/20 p-4">
                    <p className="font-semibold">{selectedBuilding ? `${selectedBuilding.street}, ${selectedBuilding.house}` : "—"}</p>
                    <p className="text-sm text-muted-foreground mt-1">квартира {selected.apartment}</p>
                    {selectedBuilding && (
                      <div className="grid grid-cols-3 gap-3 mt-3 pt-3 border-t border-border">
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-mono">Категория</p>
                          <p className="text-sm font-medium mt-0.5">{selectedBuilding.category}</p>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-mono">Год</p>
                          <p className="text-sm font-mono mt-0.5">{selectedBuilding.yearBuilt}</p>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-mono">Материал</p>
                          <p className="text-sm font-mono mt-0.5">{selectedBuilding.material}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </section>

                {linkedResident && (
                  <section>
                    <h3 className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                      <User className="w-3.5 h-3.5" /> Связь с реестром жителей
                    </h3>
                    <div className="rounded-lg border border-[hsl(160,40%,35%)]/30 bg-[hsl(160,40%,35%)]/5 p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-semibold">{linkedResident.fullName}</p>
                          <p className="text-xs text-muted-foreground font-mono mt-0.5">{linkedResident.id}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-mono">{linkedResident.age} лет</p>
                          <p className="text-xs text-muted-foreground">{linkedResident.gender === "М" ? "Мужской" : "Женский"}</p>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-3 italic">
                        Собственник проживает по адресу собственности
                      </p>
                    </div>
                  </section>
                )}

                <section>
                  <h3 className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3">Контакты</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="w-3.5 h-3.5" /> {selected.phone}
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Mail className="w-3.5 h-3.5" /> {selected.email}
                    </div>
                  </div>
                </section>

                <Button variant="outline" className="w-full" onClick={() => setSelected(null)}>
                  <X className="w-4 h-4 mr-2" /> Закрыть
                </Button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </motion.div>
  );
}
