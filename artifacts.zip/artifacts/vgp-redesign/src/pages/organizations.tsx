import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Search, Briefcase, Phone, MapPin } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { mockData } from "@/lib/mockData";

export default function Organizations() {
  const [search, setSearch] = useState("");
  const [activityFilter, setActivityFilter] = useState<string>("all");

  const activities = useMemo(() => {
    const s = new Set<string>();
    mockData.organizations.forEach((o) => s.add(o.activity));
    return Array.from(s).sort();
  }, []);

  const filtered = useMemo(() => {
    return mockData.organizations.filter((o) => {
      const matchSearch = o.name.toLowerCase().includes(search.toLowerCase()) || o.inn.includes(search);
      const matchActivity = activityFilter === "all" || o.activity === activityFilter;
      return matchSearch && matchActivity;
    });
  }, [search, activityFilter]);

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 max-w-7xl mx-auto">
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground font-mono mb-2">Раздел / Реестр</p>
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Организации</h1>
        <p className="text-muted-foreground mt-1">{filtered.length} из {mockData.organizations.length} организаций на территории микрорайона</p>
      </div>

      <Card>
        <CardContent className="p-4 flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Поиск по названию или ИНН..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={activityFilter} onValueChange={setActivityFilter}>
            <SelectTrigger className="md:w-64"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все виды деятельности</SelectItem>
              {activities.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((o, i) => (
          <motion.div key={o.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}>
            <Card className="hover:shadow-md transition-all h-full">
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="p-2 rounded-md bg-[hsl(280,25%,40%)]/10 text-[hsl(280,30%,40%)] shrink-0">
                      <Briefcase className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-mono text-xs text-muted-foreground">{o.id}</p>
                      <h3 className="font-semibold truncate">{o.legalForm} «{o.name}»</h3>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs shrink-0">{o.employees} чел.</Badge>
                </div>

                <p className="text-sm text-muted-foreground mb-3">{o.activity}</p>

                <div className="space-y-1.5 text-sm border-t border-border pt-3">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <span className="font-mono text-xs uppercase tracking-wider w-12 shrink-0">ИНН</span>
                    <span className="font-mono">{o.inn}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="w-3.5 h-3.5 shrink-0" />
                    <span>{o.address}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="w-3.5 h-3.5 shrink-0" />
                    <span>{o.phone}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
