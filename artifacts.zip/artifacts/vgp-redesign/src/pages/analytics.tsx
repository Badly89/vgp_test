import { useMemo } from "react";
import { motion } from "framer-motion";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { mockData, summary } from "@/lib/mockData";

const CHART_COLORS = [
  "hsl(25, 80%, 50%)",
  "hsl(215, 30%, 40%)",
  "hsl(160, 30%, 35%)",
  "hsl(280, 25%, 40%)",
  "hsl(45, 75%, 50%)",
];

function groupCount<T>(arr: T[], keyFn: (x: T) => string): { name: string; value: number }[] {
  const m = new Map<string, number>();
  for (const x of arr) {
    const k = keyFn(x);
    m.set(k, (m.get(k) ?? 0) + 1);
  }
  return Array.from(m.entries()).map(([name, value]) => ({ name, value }));
}

export default function Analytics() {
  const byCategory = useMemo(() => groupCount(mockData.buildings, (b) => b.category), []);
  const byMaterial = useMemo(() =>
    groupCount(mockData.buildings, (b) => b.material).sort((a, b) => b.value - a.value), []);
  const byFloors = useMemo(() => {
    const m = new Map<number, number>();
    for (const b of mockData.buildings) m.set(b.floors, (m.get(b.floors) ?? 0) + 1);
    return Array.from(m.entries()).sort((a, b) => a[0] - b[0]).map(([f, v]) => ({ name: `${f} эт.`, value: v }));
  }, []);
  const byDecade = useMemo(() => {
    const m = new Map<string, number>();
    for (const b of mockData.buildings) {
      const dec = `${Math.floor(b.yearBuilt / 10) * 10}-е`;
      m.set(dec, (m.get(dec) ?? 0) + 1);
    }
    return Array.from(m.entries()).sort().map(([d, v]) => ({ name: d, value: v }));
  }, []);

  const ageHistogram = useMemo(() => {
    const buckets = [
      { name: "0–18", value: 0 },
      { name: "19–35", value: 0 },
      { name: "36–55", value: 0 },
      { name: "56–70", value: 0 },
      { name: "71+", value: 0 },
    ];
    for (const r of mockData.residents) {
      if (r.age <= 18) buckets[0].value++;
      else if (r.age <= 35) buckets[1].value++;
      else if (r.age <= 55) buckets[2].value++;
      else if (r.age <= 70) buckets[3].value++;
      else buckets[4].value++;
    }
    return buckets;
  }, []);

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 max-w-7xl mx-auto">
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground font-mono mb-2">Раздел / Аналитика</p>
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Аналитика жилого фонда</h1>
        <p className="text-muted-foreground mt-1">Распределения, демография, состояние фонда</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          ["Объектов", summary.totalBuildings],
          ["Аварийных", summary.emergencyBuildings],
          ["Кв. м", `${(summary.totalArea / 1000).toFixed(0)}к`],
          ["Средний возраст", `${summary.averageAge} лет`],
        ].map(([k, v]) => (
          <Card key={k as string}>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">{k}</p>
              <p className="text-2xl font-bold mt-1 font-mono">{v}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Распределение по категориям</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={byCategory} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={2}>
                  {byCategory.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 6, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-6 mt-2">
              {byCategory.map((c, i) => (
                <div key={c.name} className="flex items-center gap-2 text-sm">
                  <div className="w-3 h-3 rounded-sm" style={{ background: CHART_COLORS[i % CHART_COLORS.length] }} />
                  <span>{c.name}</span>
                  <span className="text-muted-foreground font-mono">{c.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">По материалу стен</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={byMaterial}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 6, fontSize: 12 }} />
                <Bar dataKey="value" fill="hsl(25, 80%, 50%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">По этажности</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={byFloors}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 6, fontSize: 12 }} />
                <Bar dataKey="value" fill="hsl(215, 30%, 40%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">По десятилетиям постройки</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={byDecade}>
                <defs>
                  <linearGradient id="colorDec" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(160, 30%, 35%)" stopOpacity={0.6} />
                    <stop offset="100%" stopColor="hsl(160, 30%, 35%)" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 6, fontSize: 12 }} />
                <Area type="monotone" dataKey="value" stroke="hsl(160, 30%, 35%)" fill="url(#colorDec)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Демография: возрастные группы</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={ageHistogram} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis type="category" dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} width={60} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 6, fontSize: 12 }} />
                <Bar dataKey="value" fill="hsl(280, 25%, 40%)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
}
