import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Building2,
  Users,
  UsersRound,
  Briefcase,
  ArrowUpRight,
  TrendingUp,
  AlertTriangle,
  RefreshCw,
  Activity,
  MapPin,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { mockData, summary } from "@/lib/mockData";
import { format, formatDistanceToNow } from "date-fns";
import { ru } from "date-fns/locale";

const metricCards = [
  {
    label: "Объекты жилого фонда",
    value: summary.totalBuildings.toLocaleString("ru-RU"),
    delta: "+4",
    deltaLabel: "за месяц",
    icon: Building2,
    href: "/housing",
    accent: "text-[hsl(25,80%,50%)]",
    bg: "bg-[hsl(25,80%,50%)]/10",
  },
  {
    label: "Собственники",
    value: summary.totalOwners.toLocaleString("ru-RU"),
    delta: "+12",
    deltaLabel: "за месяц",
    icon: Users,
    href: "/owners",
    accent: "text-[hsl(215,30%,40%)]",
    bg: "bg-[hsl(215,30%,40%)]/10",
  },
  {
    label: "Жители",
    value: summary.totalResidents.toLocaleString("ru-RU"),
    delta: "−8",
    deltaLabel: "за месяц",
    icon: UsersRound,
    href: "/residents",
    accent: "text-[hsl(160,30%,35%)]",
    bg: "bg-[hsl(160,30%,35%)]/10",
  },
  {
    label: "Организации",
    value: summary.totalOrganizations.toLocaleString("ru-RU"),
    delta: "+1",
    deltaLabel: "за месяц",
    icon: Briefcase,
    href: "/organizations",
    accent: "text-[hsl(280,25%,40%)]",
    bg: "bg-[hsl(280,25%,40%)]/10",
  },
];

function Sparkline({ values, color = "currentColor" }: { values: number[]; color?: string }) {
  const w = 100;
  const h = 28;
  const max = Math.max(...values);
  const min = Math.min(...values);
  const range = max - min || 1;
  const pts = values
    .map((v, i) => `${(i / (values.length - 1)) * w},${h - ((v - min) / range) * h}`)
    .join(" ");
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="overflow-visible">
      <polyline fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" points={pts} />
    </svg>
  );
}

function DistrictMap() {
  return (
    <svg viewBox="0 0 320 200" className="w-full h-full">
      <defs>
        <pattern id="dots" width="8" height="8" patternUnits="userSpaceOnUse">
          <circle cx="1" cy="1" r="0.7" fill="hsl(var(--muted-foreground))" opacity="0.25" />
        </pattern>
      </defs>
      <rect width="320" height="200" fill="url(#dots)" />
      <path
        d="M 30 60 L 80 35 L 160 28 L 240 45 L 285 80 L 280 130 L 240 165 L 160 175 L 80 165 L 35 130 Z"
        fill="hsl(var(--primary))"
        fillOpacity="0.08"
        stroke="hsl(var(--primary))"
        strokeWidth="1.5"
        strokeDasharray="4 3"
      />
      {[
        [80, 80], [120, 65], [160, 75], [200, 60], [230, 95], [115, 110],
        [165, 120], [205, 135], [85, 130], [145, 145], [195, 95], [70, 100],
      ].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="3" fill="hsl(var(--primary))" opacity="0.7" />
      ))}
      <text x="160" y="20" textAnchor="middle" fontSize="11" fill="hsl(var(--muted-foreground))" fontFamily="var(--app-font-mono)">
        мкр. ВЫНГАПУР
      </text>
      <text x="160" y="195" textAnchor="middle" fontSize="9" fill="hsl(var(--muted-foreground))" fontFamily="var(--app-font-mono)" opacity="0.6">
        N 63°08′ • E 75°27′
      </text>
    </svg>
  );
}

export default function Home() {
  const today = format(new Date(), "EEEE, d MMMM yyyy", { locale: ru });
  const recentActivity = mockData.activity.slice(0, 6);
  const lastSync = mockData.syncRuns[0];

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6 max-w-7xl mx-auto"
    >
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground font-mono mb-2">
            Главная панель
          </p>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
            Реестр жилого фонда
          </h1>
          <p className="text-muted-foreground mt-2 capitalize">{today}</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground border border-border bg-card rounded-md px-3 py-2">
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Последняя синхронизация {formatDistanceToNow(new Date(lastSync.startedAt), { locale: ru, addSuffix: true })}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {metricCards.map((m, i) => {
          const Icon = m.icon;
          const sparkValues = Array.from({ length: 12 }, (_, j) => Math.sin(i + j * 0.6) * 5 + 10 + j * 0.3);
          const isNegative = m.delta.startsWith("−");
          return (
            <motion.div
              key={m.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * i }}
            >
              <Link href={m.href}>
                <Card className="hover:shadow-md transition-all hover:-translate-y-0.5 cursor-pointer group h-full">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`p-2 rounded-md ${m.bg}`}>
                        <Icon className={`w-4 h-4 ${m.accent}`} />
                      </div>
                      <ArrowUpRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground font-medium">{m.label}</p>
                      <p className="text-3xl font-bold tracking-tight">{m.value}</p>
                    </div>
                    <div className="mt-4 flex items-end justify-between">
                      <div className="flex items-center gap-1.5 text-xs">
                        <span className={`font-medium ${isNegative ? "text-destructive" : "text-[hsl(160,40%,35%)]"}`}>
                          {m.delta}
                        </span>
                        <span className="text-muted-foreground">{m.deltaLabel}</span>
                      </div>
                      <div className={m.accent}>
                        <Sparkline values={sparkValues} color="currentColor" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
            <div>
              <CardTitle className="text-base">Карта микрорайона</CardTitle>
              <p className="text-xs text-muted-foreground mt-1">Расположение объектов учёта</p>
            </div>
            <Badge variant="secondary" className="font-mono text-xs">
              <MapPin className="w-3 h-3 mr-1" />
              12 кварталов
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="bg-muted/30 rounded-md aspect-[16/9] overflow-hidden">
              <DistrictMap />
            </div>
            <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-border">
              <div>
                <p className="text-xs text-muted-foreground">Общая площадь</p>
                <p className="text-lg font-semibold mt-1 font-mono">
                  {(summary.totalArea / 1000).toFixed(1)}<span className="text-sm text-muted-foreground"> тыс. м²</span>
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Квартир</p>
                <p className="text-lg font-semibold mt-1 font-mono">
                  {summary.totalApartments.toLocaleString("ru-RU")}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Аварийных</p>
                <p className="text-lg font-semibold mt-1 font-mono text-destructive flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  {summary.emergencyBuildings}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
            <div>
              <CardTitle className="text-base">Последние события</CardTitle>
              <p className="text-xs text-muted-foreground mt-1">Журнал изменений</p>
            </div>
            <Activity className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="space-y-3 pt-0">
            {recentActivity.map((a, i) => (
              <motion.div
                key={a.id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 * i }}
                className="flex gap-3 pb-3 border-b border-border/40 last:border-0 last:pb-0"
              >
                <div className={`w-1.5 rounded-full shrink-0 ${
                  a.type === "sync" ? "bg-primary" :
                  a.type === "create" ? "bg-[hsl(160,40%,35%)]" :
                  a.type === "delete" ? "bg-destructive" :
                  "bg-muted-foreground"
                }`} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm leading-snug">{a.description}</p>
                  <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                    <span>{a.user}</span>
                    <span>•</span>
                    <span>{formatDistanceToNow(new Date(a.at), { locale: ru, addSuffix: true })}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Сводка
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">Средний возраст жителей</p>
              <p className="text-2xl font-bold mt-2 font-mono">{summary.averageAge} лет</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">Управляющих компаний</p>
              <p className="text-2xl font-bold mt-2 font-mono">4</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">Источник данных</p>
              <p className="text-2xl font-bold mt-2 font-mono">DTable</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">Версия системы</p>
              <p className="text-2xl font-bold mt-2 font-mono">v2.0</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
