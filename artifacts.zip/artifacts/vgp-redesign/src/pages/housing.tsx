import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Search, LayoutGrid, Table as TableIcon, AlertTriangle, Building2, X } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { mockData, getResidentsByBuilding, getOwnersByBuilding, type Building } from "@/lib/mockData";
import { Link } from "wouter";
import { UsersRound, Users as UsersIcon, ArrowRight } from "lucide-react";

export default function Housing() {
  const [view, setView] = useState<"table" | "grid">("table");
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [selected, setSelected] = useState<Building | null>(null);

  const filtered = useMemo(() => {
    return mockData.buildings.filter((b) => {
      const matchSearch = `${b.street} ${b.house}`.toLowerCase().includes(search.toLowerCase());
      const matchCat = category === "all" || b.category === category;
      return matchSearch && matchCat;
    });
  }, [search, category]);

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground font-mono mb-2">Раздел / Объекты</p>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Жилой фонд</h1>
          <p className="text-muted-foreground mt-1">{filtered.length} из {mockData.buildings.length} объектов</p>
        </div>
        <div className="flex items-center gap-2 border border-border rounded-md p-1 bg-card">
          <button
            onClick={() => setView("table")}
            className={`px-3 py-1.5 rounded text-sm flex items-center gap-2 transition-all ${view === "table" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
          >
            <TableIcon className="w-3.5 h-3.5" /> Таблица
          </button>
          <button
            onClick={() => setView("grid")}
            className={`px-3 py-1.5 rounded text-sm flex items-center gap-2 transition-all ${view === "grid" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
          >
            <LayoutGrid className="w-3.5 h-3.5" /> Карточки
          </button>
        </div>
      </div>

      <Card>
        <CardContent className="p-4 flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Поиск по адресу..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="md:w-56"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все категории</SelectItem>
              <SelectItem value="МКД">Многоквартирные дома</SelectItem>
              <SelectItem value="Индивидуальный">Индивидуальные</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {view === "table" ? (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-32 font-mono text-xs uppercase tracking-wider">ID</TableHead>
                  <TableHead className="font-mono text-xs uppercase tracking-wider">Адрес</TableHead>
                  <TableHead className="font-mono text-xs uppercase tracking-wider">Категория</TableHead>
                  <TableHead className="text-right font-mono text-xs uppercase tracking-wider">Этажей</TableHead>
                  <TableHead className="text-right font-mono text-xs uppercase tracking-wider">Год</TableHead>
                  <TableHead className="font-mono text-xs uppercase tracking-wider">Материал</TableHead>
                  <TableHead className="text-right font-mono text-xs uppercase tracking-wider">Площадь м²</TableHead>
                  <TableHead className="text-right font-mono text-xs uppercase tracking-wider">Квартир</TableHead>
                  <TableHead className="font-mono text-xs uppercase tracking-wider">Статус</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((b) => (
                  <TableRow
                    key={b.id}
                    onClick={() => setSelected(b)}
                    className="cursor-pointer hover:bg-muted/40"
                  >
                    <TableCell className="font-mono text-xs text-muted-foreground">{b.id}</TableCell>
                    <TableCell className="font-medium">{b.street}, {b.house}</TableCell>
                    <TableCell>
                      <Badge variant={b.category === "МКД" ? "default" : "secondary"} className="font-normal">{b.category}</Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono">{b.floors}</TableCell>
                    <TableCell className="text-right font-mono">{b.yearBuilt}</TableCell>
                    <TableCell className="text-muted-foreground">{b.material}</TableCell>
                    <TableCell className="text-right font-mono">{b.totalArea.toLocaleString("ru-RU")}</TableCell>
                    <TableCell className="text-right font-mono">{b.apartments}</TableCell>
                    <TableCell>
                      {b.emergency ? (
                        <Badge variant="destructive" className="gap-1"><AlertTriangle className="w-3 h-3" /> Аварийный</Badge>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((b, i) => (
            <motion.div key={b.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}>
              <Card onClick={() => setSelected(b)} className="cursor-pointer hover:shadow-md hover:-translate-y-0.5 transition-all h-full">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div className="p-2 rounded-md bg-primary/10 text-primary">
                      <Building2 className="w-4 h-4" />
                    </div>
                    {b.emergency && (
                      <Badge variant="destructive" className="gap-1 text-xs">
                        <AlertTriangle className="w-3 h-3" />
                      </Badge>
                    )}
                  </div>
                  <p className="font-mono text-xs text-muted-foreground">{b.id}</p>
                  <p className="font-semibold mt-1 leading-tight">{b.street}, {b.house}</p>
                  <p className="text-xs text-muted-foreground mt-1">{b.category}, {b.material}</p>
                  <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-border">
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-mono">Этажей</p>
                      <p className="font-mono font-semibold">{b.floors}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-mono">Год</p>
                      <p className="font-mono font-semibold">{b.yearBuilt}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-mono">Кв.</p>
                      <p className="font-mono font-semibold">{b.apartments}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          {selected && (
            <>
              <SheetHeader className="text-left">
                <p className="font-mono text-xs text-muted-foreground">{selected.id}</p>
                <SheetTitle className="text-2xl">{selected.street}, {selected.house}</SheetTitle>
              </SheetHeader>
              <div className="mt-6 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  {[
                    ["Категория", selected.category],
                    ["Материал стен", selected.material],
                    ["Этажность", selected.floors],
                    ["Год постройки", selected.yearBuilt],
                    ["Общая площадь", `${selected.totalArea.toLocaleString("ru-RU")} м²`],
                    ["Квартир", selected.apartments],
                    ["Управление", selected.managementCompany],
                    ["Статус", selected.emergency ? "Аварийный" : "В норме"],
                  ].map(([k, v]) => (
                    <div key={k as string} className="border-b border-border pb-2">
                      <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">{k}</p>
                      <p className="font-medium mt-1">{v}</p>
                    </div>
                  ))}
                </div>

                <div>
                  <h3 className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3">Связанные записи</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <Link href="/residents">
                      <div className="rounded-lg border border-border bg-muted/20 p-4 hover:bg-muted/40 hover:border-primary/40 transition-all cursor-pointer group">
                        <div className="flex items-start justify-between mb-2">
                          <div className="p-2 rounded-md bg-[hsl(160,30%,35%)]/10 text-[hsl(160,40%,30%)]">
                            <UsersRound className="w-4 h-4" />
                          </div>
                          <ArrowRight className="w-3.5 h-3.5 text-muted-foreground group-hover:translate-x-0.5 group-hover:text-foreground transition-all" />
                        </div>
                        <p className="text-2xl font-bold font-mono">{getResidentsByBuilding(selected.id).length}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">проживает</p>
                      </div>
                    </Link>

                    <Link href="/owners">
                      <div className="rounded-lg border border-border bg-muted/20 p-4 hover:bg-muted/40 hover:border-primary/40 transition-all cursor-pointer group">
                        <div className="flex items-start justify-between mb-2">
                          <div className="p-2 rounded-md bg-primary/10 text-primary">
                            <UsersIcon className="w-4 h-4" />
                          </div>
                          <ArrowRight className="w-3.5 h-3.5 text-muted-foreground group-hover:translate-x-0.5 group-hover:text-foreground transition-all" />
                        </div>
                        <p className="text-2xl font-bold font-mono">{getOwnersByBuilding(selected.id).length}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">собственников</p>
                      </div>
                    </Link>
                  </div>
                </div>

                <Button variant="outline" className="w-full" onClick={() => setSelected(null)}>
                  <X className="w-4 h-4 mr-2" /> Закрыть
                </Button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </motion.div>
  );
}
