import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Search, X, User, Home, ShieldCheck, FileText } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { mockData, getBuildingById, getOwnerByResidentId, isResidentOwner, type Resident } from "@/lib/mockData";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

export default function Residents() {
  const [search, setSearch] = useState("");
  const [streetFilter, setStreetFilter] = useState<string>("all");
  const [genderFilter, setGenderFilter] = useState<string>("all");
  const [selected, setSelected] = useState<Resident | null>(null);

  const streets = useMemo(() => {
    const s = new Set<string>();
    mockData.buildings.forEach((b) => s.add(b.street));
    return Array.from(s).sort();
  }, []);

  const filtered = useMemo(() => {
    return mockData.residents.filter((r) => {
      const b = getBuildingById(r.buildingId);
      const matchSearch = r.fullName.toLowerCase().includes(search.toLowerCase());
      const matchStreet = streetFilter === "all" || (b && b.street === streetFilter);
      const matchGender = genderFilter === "all" || r.gender === genderFilter;
      return matchSearch && matchStreet && matchGender;
    });
  }, [search, streetFilter, genderFilter]);

  const stats = useMemo(() => ({
    total: filtered.length,
    male: filtered.filter((r) => r.gender === "М").length,
    female: filtered.filter((r) => r.gender === "Ж").length,
    avgAge: filtered.length ? Math.round(filtered.reduce((s, r) => s + r.age, 0) / filtered.length) : 0,
  }), [filtered]);

  const selectedBuilding = selected ? getBuildingById(selected.buildingId) : null;
  const selectedOwnership = selected ? getOwnerByResidentId(selected.id) : undefined;

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 max-w-7xl mx-auto">
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground font-mono mb-2">Раздел / Реестр</p>
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Жители микрорайона</h1>
        <p className="text-muted-foreground mt-1">{filtered.length} из {mockData.residents.length} записей</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          ["Всего", stats.total],
          ["Мужчин", stats.male],
          ["Женщин", stats.female],
          ["Средний возраст", `${stats.avgAge} лет`],
        ].map(([k, v]) => (
          <Card key={k as string}>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">{k}</p>
              <p className="text-2xl font-bold mt-1 font-mono">{v}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardContent className="p-4 flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Поиск по ФИО..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={streetFilter} onValueChange={setStreetFilter}>
            <SelectTrigger className="md:w-56"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все улицы</SelectItem>
              {streets.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={genderFilter} onValueChange={setGenderFilter}>
            <SelectTrigger className="md:w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все</SelectItem>
              <SelectItem value="М">Мужчины</SelectItem>
              <SelectItem value="Ж">Женщины</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-28 font-mono text-xs uppercase tracking-wider">ID</TableHead>
                <TableHead className="font-mono text-xs uppercase tracking-wider">ФИО</TableHead>
                <TableHead className="font-mono text-xs uppercase tracking-wider">Дата рождения</TableHead>
                <TableHead className="text-right font-mono text-xs uppercase tracking-wider">Возраст</TableHead>
                <TableHead className="font-mono text-xs uppercase tracking-wider">Пол</TableHead>
                <TableHead className="font-mono text-xs uppercase tracking-wider">Адрес</TableHead>
                <TableHead className="font-mono text-xs uppercase tracking-wider">Статус</TableHead>
                <TableHead className="text-right font-mono text-xs uppercase tracking-wider">Семья</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.slice(0, 100).map((r) => {
                const b = getBuildingById(r.buildingId);
                const owner = isResidentOwner(r.id);
                return (
                  <TableRow
                    key={r.id}
                    onClick={() => setSelected(r)}
                    className="cursor-pointer hover:bg-muted/40"
                  >
                    <TableCell className="font-mono text-xs text-muted-foreground">{r.id}</TableCell>
                    <TableCell className="font-medium">{r.fullName}</TableCell>
                    <TableCell className="font-mono text-sm text-muted-foreground">{r.birthDate}</TableCell>
                    <TableCell className="text-right font-mono">{r.age}</TableCell>
                    <TableCell>
                      <Badge variant={r.gender === "М" ? "default" : "secondary"} className="font-mono w-7 justify-center">{r.gender}</Badge>
                    </TableCell>
                    <TableCell className="text-sm">{b ? `${b.street} ${b.house}, кв. ${r.apartment}` : "—"}</TableCell>
                    <TableCell>
                      {owner ? (
                        <Badge className="bg-[hsl(160,40%,35%)]/10 text-[hsl(160,45%,25%)] hover:bg-[hsl(160,40%,35%)]/20 gap-1 font-normal">
                          <ShieldCheck className="w-3 h-3" /> Собственник
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="font-normal text-muted-foreground">Проживает</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-mono">{r.familySize}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          {filtered.length > 100 && (
            <div className="px-4 py-3 text-center text-sm text-muted-foreground border-t border-border">
              Показано 100 из {filtered.length} записей. Уточните фильтры для просмотра остальных.
            </div>
          )}
        </CardContent>
      </Card>

      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          {selected && (
            <>
              <SheetHeader className="text-left">
                <p className="font-mono text-xs text-muted-foreground">{selected.id}</p>
                <SheetTitle className="text-2xl flex items-start gap-3">
                  <span>{selected.fullName}</span>
                </SheetTitle>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant={selected.gender === "М" ? "default" : "secondary"} className="font-mono">{selected.gender}</Badge>
                  <Badge variant="outline" className="font-mono">{selected.age} лет</Badge>
                  {selectedOwnership ? (
                    <Badge className="bg-[hsl(160,40%,35%)]/10 text-[hsl(160,45%,25%)] gap-1">
                      <ShieldCheck className="w-3 h-3" /> Собственник
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-muted-foreground">Проживает</Badge>
                  )}
                </div>
              </SheetHeader>

              <div className="mt-6 space-y-6">
                <section>
                  <h3 className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                    <User className="w-3.5 h-3.5" /> Личные данные
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      ["Дата рождения", format(new Date(selected.birthDate), "d MMMM yyyy", { locale: ru })],
                      ["Возраст", `${selected.age} лет`],
                      ["Пол", selected.gender === "М" ? "Мужской" : "Женский"],
                      ["Размер семьи", `${selected.familySize} чел.`],
                    ].map(([k, v]) => (
                      <div key={k as string} className="border-b border-border pb-2">
                        <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">{k}</p>
                        <p className="font-medium mt-1">{v}</p>
                      </div>
                    ))}
                  </div>
                </section>

                <section>
                  <h3 className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                    <Home className="w-3.5 h-3.5" /> Место проживания
                  </h3>
                  <div className="rounded-lg border border-border bg-muted/20 p-4">
                    <p className="font-semibold">{selectedBuilding ? `${selectedBuilding.street}, ${selectedBuilding.house}` : "—"}</p>
                    <p className="text-sm text-muted-foreground mt-1">квартира {selected.apartment}</p>
                    {selectedBuilding && (
                      <div className="grid grid-cols-3 gap-3 mt-3 pt-3 border-t border-border">
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-mono">Категория</p>
                          <p className="text-sm font-medium mt-0.5">{selectedBuilding.category}</p>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-mono">Год</p>
                          <p className="text-sm font-mono mt-0.5">{selectedBuilding.yearBuilt}</p>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-mono">Этажей</p>
                          <p className="text-sm font-mono mt-0.5">{selectedBuilding.floors}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </section>

                {selectedOwnership && (
                  <section>
                    <h3 className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                      <ShieldCheck className="w-3.5 h-3.5" /> Право собственности
                    </h3>
                    <div className="rounded-lg border border-[hsl(160,40%,35%)]/30 bg-[hsl(160,40%,35%)]/5 p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Тип собственности</span>
                        <Badge variant={selectedOwnership.ownershipType === "Частная" ? "default" : "secondary"}>
                          {selectedOwnership.ownershipType}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Доля</span>
                        <span className="font-mono font-semibold">{selectedOwnership.share}%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Основание</span>
                        <span className="font-medium text-sm text-right">{selectedOwnership.ownershipBasis}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Дата регистрации</span>
                        <span className="font-mono text-sm">{format(new Date(selectedOwnership.ownershipDate), "d MMM yyyy", { locale: ru })}</span>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-border/40">
                        <span className="text-sm text-muted-foreground flex items-center gap-1.5">
                          <FileText className="w-3.5 h-3.5" /> Документ
                        </span>
                        <span className="font-mono text-xs">{selectedOwnership.documentNumber}</span>
                      </div>
                    </div>
                  </section>
                )}

                <Button variant="outline" className="w-full" onClick={() => setSelected(null)}>
                  <X className="w-4 h-4 mr-2" /> Закрыть
                </Button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </motion.div>
  );
}
