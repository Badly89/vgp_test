import { useState } from "react";
import { motion } from "framer-motion";
import { RefreshCw, CheckCircle2, AlertCircle, AlertTriangle, Database, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { mockData } from "@/lib/mockData";
import { format, formatDistanceToNow } from "date-fns";
import { ru } from "date-fns/locale";

export default function Sync() {
  const [status, setStatus] = useState<"idle" | "syncing">("idle");
  const lastSync = mockData.syncRuns[0];

  const trigger = () => {
    setStatus("syncing");
    setTimeout(() => setStatus("idle"), 2400);
  };

  const successCount = mockData.syncRuns.filter((s) => s.status === "success").length;

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 max-w-7xl mx-auto">
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground font-mono mb-2">Раздел / Интеграция</p>
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Синхронизация данных</h1>
        <p className="text-muted-foreground mt-1">Обновление реестра из внешнего источника DTable</p>
      </div>

      <Card className="overflow-hidden">
        <div className={`h-1 transition-all ${status === "syncing" ? "bg-primary animate-pulse" : "bg-[hsl(160,40%,35%)]"}`} />
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div className="flex items-start gap-4">
              <div className={`p-3 rounded-lg ${status === "syncing" ? "bg-primary/10 text-primary" : "bg-[hsl(160,40%,35%)]/10 text-[hsl(160,40%,35%)]"}`}>
                {status === "syncing" ? (
                  <RefreshCw className="w-6 h-6 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-6 h-6" />
                )}
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider text-muted-foreground font-mono">Текущий статус</p>
                <h2 className="text-xl font-semibold mt-1">
                  {status === "syncing" ? "Идёт синхронизация..." : "Готово к работе"}
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Последний запуск {formatDistanceToNow(new Date(lastSync.startedAt), { locale: ru, addSuffix: true })} • {lastSync.recordsUpdated} записей обновлено
                </p>
              </div>
            </div>
            <Button size="lg" onClick={trigger} disabled={status === "syncing"} className="shrink-0">
              <RefreshCw className={`w-4 h-4 mr-2 ${status === "syncing" ? "animate-spin" : ""}`} />
              Синхронизировать сейчас
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "Источник", value: "DTable", icon: Database },
          { label: "Расписание", value: "Каждые 6 ч", icon: Clock },
          { label: "Успешных", value: `${successCount}/${mockData.syncRuns.length}`, icon: CheckCircle2 },
          { label: "Среднее время", value: `${Math.round(mockData.syncRuns.reduce((s, r) => s + r.durationMs, 0) / mockData.syncRuns.length / 1000)} с`, icon: Clock },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">{s.label}</p>
                    <p className="text-xl font-bold mt-1 font-mono">{s.value}</p>
                  </div>
                  <Icon className="w-4 h-4 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">История синхронизаций</CardTitle>
          <p className="text-xs text-muted-foreground">Последние {mockData.syncRuns.length} запусков</p>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {mockData.syncRuns.map((s, i) => {
              const StatusIcon = s.status === "success" ? CheckCircle2 : s.status === "error" ? AlertCircle : AlertTriangle;
              const statusColor =
                s.status === "success" ? "text-[hsl(160,40%,35%)] bg-[hsl(160,40%,35%)]/10" :
                s.status === "error" ? "text-destructive bg-destructive/10" :
                "text-[hsl(45,80%,40%)] bg-[hsl(45,80%,40%)]/10";
              return (
                <motion.div
                  key={s.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.02 }}
                  className="flex items-center gap-4 px-5 py-3 hover:bg-muted/20"
                >
                  <div className={`p-2 rounded-md ${statusColor}`}>
                    <StatusIcon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3">
                      <p className="font-mono text-xs text-muted-foreground">{s.id}</p>
                      <Badge variant={s.status === "success" ? "secondary" : s.status === "error" ? "destructive" : "outline"} className="text-xs">
                        {s.status === "success" ? "Успешно" : s.status === "error" ? "Ошибка" : "Частично"}
                      </Badge>
                    </div>
                    <p className="text-sm mt-0.5">{s.source}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-mono">{s.recordsUpdated} зап.</p>
                    <p className="text-xs text-muted-foreground font-mono">{(s.durationMs / 1000).toFixed(1)} с</p>
                  </div>
                  <div className="text-right hidden md:block w-44">
                    <p className="text-sm font-mono">{format(new Date(s.startedAt), "d MMM, HH:mm", { locale: ru })}</p>
                    <p className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(s.startedAt), { locale: ru, addSuffix: true })}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
