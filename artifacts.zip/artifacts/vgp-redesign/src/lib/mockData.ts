// Deterministic seeded mock data for VGP Housing Registry

class SeededRandom {
  private seed: number;
  constructor(seed: number) {
    this.seed = seed;
  }
  next(): number {
    this.seed = (this.seed * 9301 + 49297) % 233280;
    return this.seed / 233280;
  }
  pick<T>(arr: readonly T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
  int(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }
  bool(probTrue = 0.5): boolean {
    return this.next() < probTrue;
  }
}

const rng = new SeededRandom(42);

const STREETS = [
  "ул. Молодёжная",
  "ул. Газовиков",
  "ул. Юбилейная",
  "ул. Северная",
  "ул. Геологов",
  "ул. Строителей",
  "ул. Таёжная",
  "ул. Школьная",
  "ул. Энтузиастов",
  "ул. Первопроходцев",
  "ул. Озёрная",
  "ул. Лесная",
];

const MALE_FIRST = ["Александр", "Дмитрий", "Сергей", "Андрей", "Алексей", "Михаил", "Иван", "Николай", "Владимир", "Евгений", "Артём", "Максим", "Павел", "Роман", "Денис"];
const FEMALE_FIRST = ["Ольга", "Елена", "Татьяна", "Наталья", "Ирина", "Светлана", "Анна", "Мария", "Юлия", "Екатерина", "Людмила", "Галина", "Ксения", "Анастасия"];
const MALE_PATR = ["Александрович", "Дмитриевич", "Сергеевич", "Андреевич", "Алексеевич", "Михайлович", "Иванович", "Николаевич", "Владимирович", "Евгеньевич", "Петрович"];
const FEMALE_PATR = ["Александровна", "Дмитриевна", "Сергеевна", "Андреевна", "Алексеевна", "Михайловна", "Ивановна", "Николаевна", "Владимировна", "Евгеньевна", "Петровна"];
const SURNAMES = ["Иванов", "Петров", "Сидоров", "Кузнецов", "Смирнов", "Попов", "Васильев", "Михайлов", "Фёдоров", "Морозов", "Волков", "Соколов", "Лебедев", "Козлов", "Новиков", "Орлов", "Макаров", "Никитин", "Захаров", "Зайцев", "Соловьёв"];

const MATERIALS = ["Кирпич", "Панель", "Монолит", "Дерево", "Блок"] as const;
const CATEGORIES = ["МКД", "Индивидуальный"] as const;
const ORG_TYPES = ["ООО", "АО", "ИП", "МУП", "Бюджетное учреждение"];
const ORG_ACTIVITIES = [
  "Розничная торговля",
  "Управляющая компания",
  "Образование",
  "Здравоохранение",
  "Бытовые услуги",
  "Общественное питание",
  "Транспортные услуги",
  "Строительство",
  "Ремонт техники",
  "Финансовые услуги",
];
const ORG_NAMES = [
  "Северный Дом", "Вынгапур-Сервис", "Энергия", "Уют", "Магистраль", "Тайга", "Заря",
  "Прогресс", "Меридиан", "Айсберг", "Родник", "Стройинвест", "Альянс", "Феникс", "Кристалл",
];

export type Building = {
  id: string;
  street: string;
  house: string;
  category: typeof CATEGORIES[number];
  floors: number;
  yearBuilt: number;
  material: typeof MATERIALS[number];
  totalArea: number;
  apartments: number;
  emergency: boolean;
  managementCompany: string;
};

export type OwnershipBasis =
  | "Договор купли-продажи"
  | "Приватизация"
  | "Наследство"
  | "Дарение"
  | "Договор соц. найма"
  | "Долевое строительство";

export type OwnershipType = "Частная" | "Муниципальная";

export type Owner = {
  id: string;
  fullName: string;
  share: number;
  buildingId: string;
  apartment: number;
  phone: string;
  email: string;
  ownershipBasis: OwnershipBasis;
  ownershipType: OwnershipType;
  ownershipDate: string;
  documentNumber: string;
  residentId?: string;
};

export type Resident = {
  id: string;
  fullName: string;
  birthDate: string;
  age: number;
  gender: "М" | "Ж";
  buildingId: string;
  apartment: number;
  familySize: number;
};

export type Organization = {
  id: string;
  name: string;
  inn: string;
  legalForm: string;
  address: string;
  phone: string;
  activity: string;
  employees: number;
};

export type SyncRun = {
  id: string;
  startedAt: string;
  durationMs: number;
  status: "success" | "error" | "partial";
  recordsUpdated: number;
  source: string;
};

export type ActivityEvent = {
  id: string;
  type: "sync" | "edit" | "create" | "delete";
  description: string;
  user: string;
  at: string;
};

function randomRussianFullName(rngL: SeededRandom): { name: string; gender: "М" | "Ж" } {
  const isMale = rngL.bool();
  const surname = rngL.pick(SURNAMES);
  if (isMale) {
    return { name: `${surname} ${rngL.pick(MALE_FIRST)} ${rngL.pick(MALE_PATR)}`, gender: "М" };
  }
  return { name: `${surname}а ${rngL.pick(FEMALE_FIRST)} ${rngL.pick(FEMALE_PATR)}`, gender: "Ж" };
}

function randomPhone(rngL: SeededRandom): string {
  return `+7 (3496) ${String(rngL.int(100, 999)).padStart(3, "0")}-${String(rngL.int(10, 99)).padStart(2, "0")}-${String(rngL.int(10, 99)).padStart(2, "0")}`;
}

function randomINN(rngL: SeededRandom): string {
  let s = "";
  for (let i = 0; i < 10; i++) s += String(rngL.int(0, 9));
  return s;
}

function generate() {
  const buildings: Building[] = [];
  const usedAddresses = new Set<string>();

  for (let i = 0; i < 72; i++) {
    let street: string, house: string, addr: string;
    do {
      street = rng.pick(STREETS);
      house = String(rng.int(1, 80)) + (rng.bool(0.15) ? `/${rng.int(1, 4)}` : "");
      addr = `${street} ${house}`;
    } while (usedAddresses.has(addr));
    usedAddresses.add(addr);

    const category = rng.pick(CATEGORIES);
    const isMKD = category === "МКД";
    const floors = isMKD ? rng.int(2, 9) : rng.int(1, 2);
    const apartments = isMKD ? rng.int(8, 90) : 1;
    const totalArea = isMKD ? rng.int(800, 6500) : rng.int(60, 220);

    buildings.push({
      id: `B${String(i + 1).padStart(4, "0")}`,
      street,
      house,
      category,
      floors,
      yearBuilt: rng.int(1968, 2023),
      material: rng.pick(MATERIALS),
      totalArea,
      apartments,
      emergency: rng.bool(0.06),
      managementCompany: rng.pick(["УК Северный Дом", "УК Вынгапур-Сервис", "УК Уют", "Самоуправление"]),
    });
  }

  const residents: Resident[] = [];
  for (let i = 0; i < 320; i++) {
    const b = rng.pick(buildings);
    const { name, gender } = randomRussianFullName(rng);
    const age = rng.int(1, 88);
    const year = 2026 - age;
    const month = String(rng.int(1, 12)).padStart(2, "0");
    const day = String(rng.int(1, 28)).padStart(2, "0");
    residents.push({
      id: `R${String(i + 1).padStart(5, "0")}`,
      fullName: name,
      birthDate: `${year}-${month}-${day}`,
      age,
      gender,
      buildingId: b.id,
      apartment: rng.int(1, Math.max(1, b.apartments)),
      familySize: rng.int(1, 6),
    });
  }

  const adultResidents = residents.filter((r) => r.age >= 18);
  const usedResidentIds = new Set<string>();

  const owners: Owner[] = [];
  for (let i = 0; i < 220; i++) {
    const linkToResident = rng.bool(0.65) && adultResidents.length > 0;
    let buildingId: string;
    let apartment: number;
    let fullName: string;
    let residentId: string | undefined;

    if (linkToResident) {
      let attempts = 0;
      let r = rng.pick(adultResidents);
      while (usedResidentIds.has(r.id) && attempts < 10) {
        r = rng.pick(adultResidents);
        attempts++;
      }
      if (!usedResidentIds.has(r.id)) {
        usedResidentIds.add(r.id);
        residentId = r.id;
        buildingId = r.buildingId;
        apartment = r.apartment;
        fullName = r.fullName;
      } else {
        const b = rng.pick(buildings);
        buildingId = b.id;
        apartment = rng.int(1, Math.max(1, b.apartments));
        fullName = randomRussianFullName(rng).name;
      }
    } else {
      const b = rng.pick(buildings);
      buildingId = b.id;
      apartment = rng.int(1, Math.max(1, b.apartments));
      fullName = randomRussianFullName(rng).name;
    }

    const ownershipType: OwnershipType = rng.bool(0.85) ? "Частная" : "Муниципальная";
    const ownershipBasis: OwnershipBasis = ownershipType === "Муниципальная"
      ? "Договор соц. найма"
      : rng.pick([
          "Договор купли-продажи",
          "Приватизация",
          "Наследство",
          "Дарение",
          "Долевое строительство",
        ] as const);

    const ownYear = rng.int(1995, 2025);
    const ownMonth = String(rng.int(1, 12)).padStart(2, "0");
    const ownDay = String(rng.int(1, 28)).padStart(2, "0");

    owners.push({
      id: `O${String(i + 1).padStart(5, "0")}`,
      fullName,
      share: rng.pick([100, 50, 33, 25, 75]),
      buildingId,
      apartment,
      phone: randomPhone(rng),
      email: `owner${i + 1}@vgp.ru`,
      ownershipBasis,
      ownershipType,
      ownershipDate: `${ownYear}-${ownMonth}-${ownDay}`,
      documentNumber: `${rng.int(10, 99)}-АА № ${rng.int(100000, 999999)}`,
      residentId,
    });
  }

  const organizations: Organization[] = [];
  for (let i = 0; i < 32; i++) {
    const b = rng.pick(buildings);
    organizations.push({
      id: `ORG${String(i + 1).padStart(4, "0")}`,
      name: `${rng.pick(ORG_NAMES)}${rng.bool(0.3) ? "-" + rng.pick(["Север", "Сервис", "Плюс", "Групп"]) : ""}`,
      inn: randomINN(rng),
      legalForm: rng.pick(ORG_TYPES),
      address: `${b.street} ${b.house}`,
      phone: randomPhone(rng),
      activity: rng.pick(ORG_ACTIVITIES),
      employees: rng.int(2, 120),
    });
  }

  const syncRuns: SyncRun[] = [];
  const now = Date.now();
  for (let i = 0; i < 12; i++) {
    const startedAt = new Date(now - i * 1000 * 60 * 60 * 6 - rng.int(0, 1000 * 60 * 30)).toISOString();
    const status: SyncRun["status"] = rng.bool(0.85) ? "success" : rng.bool(0.5) ? "partial" : "error";
    syncRuns.push({
      id: `S${String(i + 1).padStart(4, "0")}`,
      startedAt,
      durationMs: rng.int(8_000, 95_000),
      status,
      recordsUpdated: status === "error" ? 0 : rng.int(20, 480),
      source: "DTable / Вынгапур",
    });
  }

  const activity: ActivityEvent[] = [];
  for (let i = 0; i < 18; i++) {
    const type = rng.pick(["sync", "edit", "create", "delete"] as const);
    const at = new Date(now - i * 1000 * 60 * rng.int(15, 240)).toISOString();
    const user = rng.pick(["Иванов А.С.", "Петрова Е.М.", "Сидоров Д.В.", "Система"]);
    let description = "";
    if (type === "sync") description = `Синхронизация с DTable: ${rng.int(50, 320)} записей`;
    else if (type === "edit") description = `Изменены данные: ${rng.pick(STREETS)} ${rng.int(1, 50)}`;
    else if (type === "create") description = `Добавлен ${rng.pick(["собственник", "житель", "объект"])}`;
    else description = `Удалена устаревшая запись`;
    activity.push({
      id: `A${i + 1}`,
      type,
      description,
      user,
      at,
    });
  }

  return { buildings, owners, residents, organizations, syncRuns, activity };
}

export const mockData = generate();

export function getBuildingById(id: string): Building | undefined {
  return mockData.buildings.find((b) => b.id === id);
}

export function getResidentsByBuilding(buildingId: string): Resident[] {
  return mockData.residents.filter((r) => r.buildingId === buildingId);
}

export function getOwnersByBuilding(buildingId: string): Owner[] {
  return mockData.owners.filter((o) => o.buildingId === buildingId);
}

export function getOwnerByResidentId(residentId: string): Owner | undefined {
  return mockData.owners.find((o) => o.residentId === residentId);
}

export function getResidentByOwnerId(ownerId: string): Resident | undefined {
  const owner = mockData.owners.find((o) => o.id === ownerId);
  if (!owner || !owner.residentId) return undefined;
  return mockData.residents.find((r) => r.id === owner.residentId);
}

export function isResidentOwner(residentId: string): boolean {
  return mockData.owners.some((o) => o.residentId === residentId);
}

export const summary = {
  totalBuildings: 277,
  totalOwners: 1640,
  totalResidents: 5002,
  totalOrganizations: 54,
  emergencyBuildings: mockData.buildings.filter((b) => b.emergency).length,
  averageAge: Math.round(mockData.residents.reduce((s, r) => s + r.age, 0) / mockData.residents.length),
  totalArea: mockData.buildings.reduce((s, b) => s + b.totalArea, 0),
  totalApartments: mockData.buildings.reduce((s, b) => s + b.apartments, 0),
};
