import React from 'react';
import { Link, useLocation } from 'wouter';
import { 
  Building2, 
  Users, 
  UsersRound, 
  Briefcase, 
  BarChart3, 
  RefreshCw, 
  Home,
  Search,
  Calendar as CalendarIcon
} from 'lucide-react';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';

import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function Sidebar() {
  const [location] = useLocation();

  const links = [
    { href: '/', label: 'Главная', icon: Home },
    { href: '/housing', label: 'Жилой фонд', icon: Building2 },
    { href: '/owners', label: 'Собственники', icon: Users },
    { href: '/residents', label: 'Жители', icon: UsersRound },
    { href: '/organizations', label: 'Организации', icon: Briefcase },
    { href: '/dashboard', label: 'Аналитика', icon: BarChart3 },
    { href: '/sync', label: 'Синхронизация', icon: RefreshCw },
  ];

  return (
    <div className="w-64 border-r border-border bg-sidebar h-screen sticky top-0 flex flex-col hidden md:flex shrink-0">
      <div className="p-6 h-16 flex items-center border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 text-primary p-2 rounded-lg">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-semibold text-sm leading-tight text-foreground tracking-tight">Реестр жилого фонда</h1>
            <p className="text-xs text-muted-foreground leading-tight">мкр. Вынгапур</p>
          </div>
        </div>
      </div>

      <div className="p-4 flex-1 flex flex-col gap-1 overflow-y-auto">
        {links.map((link) => {
          const isActive = location === link.href || (link.href !== '/' && location.startsWith(link.href));
          const Icon = link.icon;
          
          return (
            <Link key={link.href} href={link.href} className={`flex items-center gap-3 px-3 py-2.5 rounded-md transition-all text-sm font-medium ${
              isActive 
                ? 'bg-primary text-primary-foreground shadow-sm' 
                : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
            }`}>
              <Icon className="w-4 h-4" />
              {link.label}
            </Link>
          );
        })}
      </div>
      
      <div className="p-4 border-t border-border/50 text-xs text-muted-foreground text-center">
        Система учета v2.0
      </div>
    </div>
  );
}

export function Header() {
  const today = format(new Date(), 'd MMMM yyyy, eeee', { locale: ru });

  return (
    <header className="h-16 border-b border-border bg-background flex items-center justify-between px-6 sticky top-0 z-10">
      <div className="flex items-center gap-4 flex-1">
        <div className="relative w-full max-w-sm hidden sm:block">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            type="search" 
            placeholder="Быстрый поиск (адрес, ФИО, ИНН)..." 
            className="pl-9 bg-muted/50 border-transparent focus-visible:bg-background transition-colors"
          />
        </div>
      </div>
      
      <div className="flex items-center gap-6">
        <div className="hidden lg:flex items-center gap-2 text-sm text-muted-foreground font-medium">
          <CalendarIcon className="w-4 h-4" />
          <span className="capitalize">{today}</span>
        </div>
        
        <div className="flex items-center gap-3 border-l border-border pl-6">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-medium leading-none">Иванов А.С.</p>
            <p className="text-xs text-muted-foreground mt-1">Администратор</p>
          </div>
          <Avatar className="h-9 w-9 border border-border">
            <AvatarFallback className="bg-primary/10 text-primary font-medium">АИ</AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}

export function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-muted/20">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        <main className="flex-1 p-6 overflow-x-hidden">
          {children}
        </main>
      </div>
    </div>
  );
}
