import { AppLayout } from "./components/layout";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

// Import pages
import Home from "@/pages/home";
import Housing from "@/pages/housing";
import Owners from "@/pages/owners";
import Residents from "@/pages/residents";
import Organizations from "@/pages/organizations";
import Analytics from "@/pages/analytics";
import Sync from "@/pages/sync";

const queryClient = new QueryClient();

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/housing" component={Housing} />
        <Route path="/owners" component={Owners} />
        <Route path="/residents" component={Residents} />
        <Route path="/organizations" component={Organizations} />
        <Route path="/dashboard" component={Analytics} />
        <Route path="/sync" component={Sync} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
